<?php include './views/partials/header.php'; ?>
<div class="container">
    <h2>Đăng ký tài khoản</h2>
    <form action="#" method="post">
        <input type="text" name="fullname" placeholder="Họ và tên">
        <input type="email" name="email" placeholder="Email">
        <input type="password" name="password" placeholder="Mật khẩu">
        <input type="submit" value="Đăng ký">
    </form>
</div>
<?php include './views/partials/footer.php'; ?>
