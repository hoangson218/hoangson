<?php include './views/partials/header.php'; ?>
<div class="container">
    <h2>Đăng nhập</h2>
    <form action="#" method="post">
        <input type="email" name="email" placeholder="Email">
        <input type="password" name="password" placeholder="Mật khẩu">
        <input type="submit" value="Đăng nhập">
    </form>
</div>
<?php include './views/partials/footer.php'; ?>
